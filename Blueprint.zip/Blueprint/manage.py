# -*- coding:utf-8 -*-
from flask import Flask,make_response
from users import user_blue
from admin import admin_blue
from config import Config
from app_utils import str_split
from flask_wtf.csrf import CSRFProtect,generate_csrf
from users.views import UserView

app = Flask(__name__)
app.register_blueprint(user_blue,url_prefix='/user')
app.register_blueprint(admin_blue,url_prefix='/admin')
app.config.from_object(Config)
app.jinja_env.filters["str_split"] = str_split
app.add_url_rule('/user/flash',view_func=UserView.as_view('user'))
CSRFProtect(app)

@app.after_request
def after_request(response):

    csrf_token = generate_csrf()
    response.set_cookie('csrf_token',csrf_token)
    return response

if __name__ == "__main__":
    print(app.url_map)
    app.run(debug=True)



