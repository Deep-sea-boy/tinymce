from . import admin_blue
from flask import jsonify

@admin_blue.route('/get_admin')
def get_admin():
    return "admin_blue is here"


