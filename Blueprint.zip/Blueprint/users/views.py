# -*- coding:utf-8 -*-
from . import user_blue
from flask import render_template,redirect,url_for
from Blueprint.wtf import WtfForm
from flask import request,jsonify
from flask.views import MethodView
from flask_wtf.csrf import CSRFProtect
csrf = CSRFProtect()

@user_blue.route("/get_user")
def get_user():
    return "user_blue is here!"


@user_blue.route("/goh5")
def goh5():

    data = dict(
        name = 'name',
        age = '18',
        form = WtfForm()
    )
    return render_template('test.html',**data)

class UserView(MethodView):
    def get(self):
        return redirect(url_for('user.goh5'))
    def post(self):
        json_dict = request.json
        num = json_dict.get("num")
        if num>3:
            return jsonify(status=0)
        else:
            return jsonify(status=1)
    def put(self):
        json_dict = request.json
        num = json_dict.get("num")
        if num>3:
            return jsonify(status=0)
        else:
            return jsonify(status=1)
    def delete(self):
        json_dict = request.json
        num = json_dict.get("num")
        if num>3:
            return jsonify(status=0)
        else:
            return jsonify(status=1)

@user_blue.route("/login",methods=["GET","POST"])
def login():

    name = request.form.get("name")
    img = request.files.get("photo")
    img_name = img.filename
    if img_name.split('.')[1] not in ['png', 'jpg', 'JPG', 'PNG', 'gif', 'GIF']:
        return 'is not photo'
    img.save('zhs.jpg')
    return '%s,%s'%(name,img_name)


@user_blue.route('/tiny')
def tiny():

    return render_template('tiny.html')

@user_blue.route('/get_html_content',methods=["POST"])
def get_html_content():

    content = request.form.get("content")
    return jsonify(html=content)

@csrf.exempt
@user_blue.route('/uploadimage',methods=["POST"])
def uploadimage():

    img = request.files.get("file")
    # return "uploadimage is here"
    return jsonify(url='https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2540594264,2400204506&fm=26&gp=0.jpg')