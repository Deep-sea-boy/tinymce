# -*- coding:utf-8 -*-
from flask_wtf import FlaskForm
from wtforms.fields import (StringField, PasswordField, DateField, BooleanField,
                            SelectField, SelectMultipleField, TextAreaField,
                            RadioField, IntegerField, DecimalField, SubmitField)
from wtforms.validators import DataRequired, InputRequired, Length, Email, EqualTo, NumberRange


class WtfForm(FlaskForm):
    # StringField 文本输入框，必填，用户名长度为4到25之间，占位符
    username = StringField(u'用户名：', validators=[Length(min=4, max=25)], render_kw={'placeholder': u'请输入用户名'})

    # Email格式
    email = StringField(u'邮箱地址：', validators=[Email()], render_kw={'placeholder': u'请输入邮箱地址'})

    # PasswordField，密码输入框，必填
    password = PasswordField(u'密码：', validators=[DataRequired()], render_kw={'placeholder': u'请输入密码'})

    # 确认密码，必须和密码一致
    password2 = PasswordField(u'确认密码：', validators=[InputRequired(), EqualTo('password', u'两次密码要一致')])

    # IntegerField，文本输入框，必须输入整型数值，范围在16到70之间
    age = IntegerField(u'年龄：', validators=[NumberRange(min=16, max=70)])

    # DecimalField，文本输入框，必须输入数值，显示时保留一位小数
    height = DecimalField(u'身高(cm):', places=1)

    # DateField，文本输入框，必须输入是"年-月-日"格式的日期
    birthday = DateField(u'出生日期：', format='%Y-%m-%d')

    # RadioField，单选框，choices里的内容会在ul标签里，里面每个项是(值，显示名)对
    gender = RadioField(u'性别：', choices=[('0', u'男'), ('1', u'女')], validators=[DataRequired()])

    # SelectField，下拉单选框，choices里的内容会在Option里，里面每个项是(值，显示名)对
    job = SelectField(u'职业：', choices=[
        ('teacher', u'教师'),
        ('doctor', u'医生'),
        ('engineer', u'工程师'),
        ('lawyer', u'律师')
    ])

    # Select类型，多选框，choices里的内容会在Option里，里面每个项是(值，显示名)对
    hobby = SelectMultipleField(u'爱好：', choices=[
        ('0', u'吃饭'),
        ('1', u'睡觉'),
        ('2', u'敲代码')
    ])

    # TextAreaField，段落输入框
    description = TextAreaField(u'自我介绍：', validators=[InputRequired()], render_kw={'placeholder': u'例：小明，18岁，未婚找女友'})

    # BooleanField，Checkbox类型，加上default='checked'即默认是选上的
    accept_terms = BooleanField(u'是否接受上述条款', default='checked', validators=[DataRequired()])

    # SubmitField，Submit按钮
    submit = SubmitField(u'提交')
