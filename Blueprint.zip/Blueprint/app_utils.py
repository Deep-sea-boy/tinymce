# -*- coding:utf-8 -*-

def str_split(string):

    string = string.split("-")

    return string
